import os

import numpy as np
from docs.concepts import file


def f():
    x = 1
