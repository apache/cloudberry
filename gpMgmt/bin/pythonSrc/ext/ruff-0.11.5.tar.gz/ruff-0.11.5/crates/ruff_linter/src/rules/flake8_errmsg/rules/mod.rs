pub(crate) use string_in_exception::*;

mod string_in_exception;
